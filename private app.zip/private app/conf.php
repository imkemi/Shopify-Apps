<?php

	define('SHOPIFY_SHOP', 'kemijeronone-2.myshopify.com');
	define('SHOPIFY_APP_API_KEY', 'fdc4206b6f459a5820da6edd4c5ed791 ');
	define('SHOPIFY_APP_PASSWORD', 'bc62409efaf26dc1f0f0cbb777708cc5 ');

?>
