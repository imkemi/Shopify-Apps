<?php
    require 'shopify.php';
include 'access.php';

    /* Define your APP`s key and secret*/
    define('SHOPIFY_API_KEY','1e4750307647987c2eec06a22213f4eb');
    define('SHOPIFY_SECRET','1c913473dff6519926539e4644989705');

    /* Define requested scope (access rights) - checkout https://docs.shopify.com/api/authentication/oauth#scopes   */
    define('SHOPIFY_SCOPE','write_content'); //eg: define('SHOPIFY_SCOPE','read_orders,write_orders');

    if (isset($_GET['code'])) { // if the code param has been sent to this page... we are in Step 2
        // Step 2: do a form POST to get the access token
        $shopifyClient = new ShopifyClient($_GET['shop'], "", SHOPIFY_API_KEY, SHOPIFY_SECRET);
        session_unset();

        // Now, request the token and store it in your session.
        $_SESSION['token'] = $shopifyClient->getAccessToken($_GET['code']);
        if ($_SESSION['token'] != '')
            $_SESSION['shop'] = $_GET['shop'];

        header("Location: index.php");
        exit;       
    }
    // if they posted the form with the shop name
    else if (isset($_POST['shop'])) {

        // Step 1: get the shopname from the user and redirect the user to the
        // shopify authorization page where they can choose to authorize this app
        $shop = isset($_POST['shop']) ? $_POST['shop'] : $_GET['shop'];
        $shopifyClient = new ShopifyClient($shop, "", SHOPIFY_API_KEY, SHOPIFY_SECRET);

        // get the URL to the current page
        $pageURL = 'http';
        if ($_SERVER["HTTPS"] == "on") { $pageURL .= "s"; }
        $pageURL .= "://";
        if ($_SERVER["SERVER_PORT"] != "80") {
            $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["SCRIPT_NAME"];
        } else {
            $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["SCRIPT_NAME"];
        }

        // redirect to authorize url
        header("Location: " . $shopifyClient->getAuthorizeUrl(SHOPIFY_SCOPE, $pageURL));
        exit;
    }

    // first time to the page, show the form below
?>
   
<div class="col-md-12">
<div class="col-md-3"></div>
   <div class="col-md-6" style="text-align:center; border:1px solid grey;margin-top:150px;">
    <p style="padding-bottom: 1em;">
     <h1> This is a Kemi Test Shopify App</h1>      
    </p> 

    <form action="" method="post">
      <label for='shop'><strong>The URL of the Shop</strong> 
        <span class="hint">(enter it your shopify store name like: myshop.myshopify.com)</span> 
      </label> 
      <p> 
        <input id="shop" name="shop" size="55" type="text" value="" /> 
        <input name="commit" type="submit" value="Install" /> 
      </p> 
    </form>
</div>
<div class="col-md-3"></div>
</div>
