<?php
include 'access.php';
?>

<div class="col-md-12">
<div class="col-md-3"></div>
   <div class="col-md-6" style="text-align:center; border:1px solid grey;margin-top:150px;">


<h1>WELCOME THIS IS THE APP DASHBOARD</h1>
<h2>Congratulation you are succesfully installed this app</h2>
</div><div class="col-md-3"></div>
</div>

